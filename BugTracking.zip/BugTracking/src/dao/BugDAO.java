package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import model.Bug;
import model.Developer;
import utility.DBConnection;

public class BugDAO {

	public void addbug(Bug bug) throws SQLException {
		// TODO Auto-generated method stub
		String query = "INSERT INTO bugs"
				+ "(bug_description, category_id, assigned_to, status, created_date)"
				+ "VALUES(?,?,?,?,?)";
		try(Connection con = DBConnection.getConnection();
				PreparedStatement ps = con.prepareStatement(query))
		{
			ps.setString(1, bug.getDescription());
			ps.setInt(2, bug.getCategory_id());
			ps.setInt(3, bug.getAssigned_to());
			ps.setString(4, bug.getStatus());
			ps.setTimestamp(5,new Timestamp(bug.getCreatedDate().getTime()) );
			ps.executeUpdate();
		}
		
	}

	public List<Bug> getAllBugs() throws SQLException{
		// TODO Auto-generated method stub
		List<Bug> bugs = new ArrayList<>();
		String query = "SELECT * FROM bugs";
		try(Connection con = DBConnection.getConnection();
			Statement s = con.createStatement();
				ResultSet result = s.executeQuery(query))
		{
			while(result.next())
			{
				Bug obj= new Bug();
				obj.setBug_id(result.getInt("bug_id"));
				obj.setDescription(result.getString("description"));
				obj.setCategory_id(result.getInt("category_id"));
				obj.setAssigned_to(result.getInt("assigned_to"));
				obj.setStatus(result.getString("status"));
				obj.setCreatedDate(result.getTimestamp("created_date"));
				obj.setResolvedDate(result.getTimestamp("resolved_date"));
				bugs.add(obj);
			}
		}return bugs;
		}
		
		public void updateBug(Bug bug) throws SQLException
		{
			String query = "UPDATE bugs "
					+ "SET description=?,category_id=? "
					+"assigned_to=?, status=?, resolved_date=?"
					+"WHERE developer_id=?";
			try(Connection con = DBConnection.getConnection();
					PreparedStatement ps = con.prepareStatement(query))
			{
				ps.setString(1, bug.getDescription());
				ps.setInt(2, bug.getCategory_id());
				ps.setInt(3, bug.getAssigned_to());
				ps.setString(3, bug.getStatus());
				ps.setTimestamp(5,new Timestamp(bug.getCreatedDate().getTime()) );
				ps.setInt(6, bug.getBug_id());
				ps.executeUpdate();
			}
			
		
	}
		public void deleteBug(int bugId) throws SQLException
		{
			String query = "DELETE FROM bugs "
					+ "WHERE bug_id=?";
			try(Connection con = DBConnection.getConnection();
					PreparedStatement ps = con.prepareStatement(query))
			{
				ps.setInt(1, bugId);
				ps.executeUpdate();
			}
		}
		public List<Bug> getBugsWithCategory() throws SQLException{
			List<Bug> bugs = new ArrayList<>();
			String query = "select b.*,c.category_name"
					+"from bugs b join categories c ON"
					+"b.caegory_id = c.category_id";
			try(Connection con = DBConnection.getConnection();
					PreparedStatement ps = con.prepareStatement(query);
					ResultSet result = ps.executeQuery(query))
			{
				while(result.next()) {
					Bug bug = new Bug();
					bug.setBug_id(result.getInt("bug_id"));
					bug.setDescription(result.getString("description"));
					bug.setCategory_id(result.getInt("category_id"));
					bug.setStatus(result.getString("status"));
					bug.setCreatedDate(result.getTimestamp("created_date"));
					bug.setResolvedDate(result.getTimestamp("resolved_date"));
					
					bug.setDescription(result.getString("description")
							+"(Category: "+result.getString("category_name"));
					bugs.add(bug);
				}
		}return bugs;

}
		public List<String> getBugsWithDeveloperDetails() throws SQLException{
			List<String> result = new ArrayList<>();
			String query = "select b.bug_id, b.description,"
					+ "d.developer_name, d.developer_email from bugs b join developer d"
					+ "on b.assigned_to = d.developer_id";
			try(Connection con = DBConnection.getConnection();
					PreparedStatement ps = con.prepareStatement(query);
					ResultSet res = ps.executeQuery(query)){
				while(res.next()) {
				String x = "Bug ID " +res.getInt("bug_id")
						+ "Description: "+res.getString("description")+"Assigned to: "+res.getString("developer_name")+
								"email: "+res.getString("email");
				result.add(x);
			}
}return result;
}
		public List<Bug> getBugAssigned(String devName) throws SQLException{
			List<Bug> bugs = new ArrayList<>();
			String query = "Select b.* from bugs b Join developers d ON"+" b.assigned_to = d.developer_id where d.name=?";
			try(Connection connection = DBConnection.getConnection();
					PreparedStatement statement = connection.prepareStatement(query))
					{
				statement.setString(1, devName);
					
					try(ResultSet resultSet = statement.executeQuery(query)){
				while(resultSet.next()) {
					Bug bug= new Bug();
					bug.setBug_id(resultSet.getInt("bug_id"));
					bug.setDescription(resultSet.getString("description"));
					bug.setCategory_id(resultSet.getInt("category_id"));
					bug.setAssigned_to(resultSet.getInt("assigned_to"));
					bug.setStatus(resultSet.getString("status"));
					bug.setCreatedDate(resultSet.getTimestamp("created_date"));
					bug.setResolvedDate(resultSet.getTimestamp("resolved_date"));
					bugs.add(bug);
				}}
			}return bugs;
}

		public int getMaxBugsAssigned() throws SQLException {
			String query = "select max(bug_count) as max_bugs "
					+"from (select count(*) as bug_count from)"
					+"bugs group by assigned_to ) as bug_counts";
			try(Connection con = DBConnection.getConnection();
					Statement s = con.createStatement();
			ResultSet res = s.executeQuery(query)){
				if(res.next()) {
					return res.getInt("max_bugs");
				}
			}
			return 0;		
		}
}