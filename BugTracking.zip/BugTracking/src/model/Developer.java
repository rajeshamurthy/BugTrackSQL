package model;

public class Developer {
	private int developerId;
	private String name;
	private String email;
	
//	default constructor		
	public Developer() {
		super();
	}
//	parameterized constructor	

	public Developer(int developerId, String name, String email) {
		super();
		this.developerId = developerId;
		this.name = name;
		this.email = email;
	}
//	Getters & Setters
	public int getDeveloperId() {
		return developerId;
	}

	public void setDeveloperId(int developerId) {
		this.developerId = developerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	


}
