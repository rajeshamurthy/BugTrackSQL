import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import controller.BugTrackingController;
import model.Bug;
import model.Category;
import model.Developer;

public class Main {

	public static void main(String[] args) throws NumberFormatException,
	IOException, SQLException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(
				new InputStreamReader(System.in));
		BugTrackingController controller = new
				BugTrackingController();
		
		while(true)
		{
			System.out.println("Bug Tracking System");
			System.out.println("1.Add Category");
			System.out.println("2.Update Category");
			System.out.println("3.List All Categories");
			System.out.println("4.Delete Category");
			System.out.println("5.Add Developer");
			System.out.println("6.Update Developer");
			System.out.println("7.List All CaDeveloper");
			System.out.println("8.Delete Developer");
			System.out.println("9. Add Bug");
			System.out.println("10.List all Bugs");
			System.out.println("11. Update Bug");
			System.out.println("12. Delete Bug");
			System.out.println("13. List Bugs with Category Names");
			System.out.println("14. List Bugs assigned to a Developer Details");
			System.out.println("15. Enter developer name");
			System.out.println("16. Exit");
			
			
			
			int choice = Integer.parseInt(br.readLine());
			
			switch(choice)
			{
			case 1:System.out.println("Enter category name: ");
					String name = br.readLine();
					controller.addCategory(new Category(0,name));
					break;
					
			case 2:System.out.println("Enter Category ID");
					int updateCategoryId = Integer.parseInt(br.readLine());
					System.out.println("Enter New Category Name");
					String Updatename = br.readLine();
					controller.updateCategory(new Category(
							updateCategoryId,Updatename));
					break;
					
			case 3: List<Category> categories = controller.getAllCategories();
					for(Category category: categories)
					{
						System.out.println
						("ID: "+category.getCategoryId()+" Name: "
						+category.getCategoryName());
					}
					break;
					
			case 4:System.out.println("Enter Category ID to be Deleted");
					int deleteCategoryId = Integer.parseInt(br.readLine());
					controller.deleteCategory(deleteCategoryId);
					break;
			
			case 5:System.out.println("Enter developer name: ");
				   String developerName = br.readLine();
				   System.out.println("Enter developer email: ");
				   String email = br.readLine();
				   controller.addDeveloper(new Developer(0,developerName,email));
			break;
			
			case 6:System.out.println("Enter Developer ID");
				int updateDeveloperId = Integer.parseInt(br.readLine());
				System.out.println("Enter New Developer Name");
				String UpdateDevelopername = br.readLine();
				System.out.println("Enter New Developer Email");
				String UpdateDeveloperEmail = br.readLine();
				controller.updateDeveloper(new Developer(updateDeveloperId,
						UpdateDevelopername,UpdateDeveloperEmail));
				break;
			
			case 7: List<Developer> developers = controller.getAllDevelopers();
					for(Developer Developer: developers)
					{
						System.out.println
						("ID: "+Developer.getDeveloperId()+" Name: "
						+Developer.getName() +
						"Email: "+Developer.getEmail());
					}
					break;
			
			case 8:System.out.println("Enter Developer ID to be Deleted");
					int deleteDeveloperId = Integer.parseInt(br.readLine());
					controller.deleteDeveloper(deleteDeveloperId);
					break;
					
			case 9:System.out.println("Enter Bug Description");
					String desc = br.readLine();
					System.out.println("Enter Category ID");
					int category_id = Integer.parseInt(br.readLine());
					System.out.println("Enter assigned Developer ID");
					int developer_id = Integer.parseInt(br.readLine());
					System.out.println("Assigned to");
					int assigned_to = Integer.parseInt(br.readLine());
					controller.addBug(new Bug(0, desc, category_id, developer_id, assigned_to, "open", new Date(), null));
					break;
					
			
			case 10: List<Bug> bugs = controller.getAllBugs();
					for(Bug bug: bugs) {
						System.out.println("ID: "+bug.getBug_id()+"Category_ID:"
								+bug.getCategory_id()+" Developer_ID:"+bug.getAssigned_to()
								+"Status:"+bug.getStatus());
					}
					break;
			
			case 11: System.out.println("Enter Bug ID");
						int UpdateBugId = Integer.parseInt(br.readLine());
						System.out.println("Enter New Bug Name");
						String UpdateDesc = br.readLine();
						System.out.println("Enter New Category ID");
						int UpdateCategoryID = Integer.parseInt(br.readLine());
						System.out.println("Enter New Developer ID");
						int UpdateDeveloperID = Integer.parseInt(br.readLine());
						System.out.println("Assigned to");
						int AssignedTo = Integer.parseInt(br.readLine());
						System.out.println("Enter new Bug Status");
						String UpdateStatus = br.readLine();
						System.out.println("Enter Bug Resolved Date(yyy-mm-dd hh:mm:ss)");
						String resolvedDate = br.readLine();
						Date rDate = resolvedDate.isEmpty()? null: Timestamp.valueOf(resolvedDate);
						controller.updateBug(new Bug(UpdateBugId, UpdateDesc, UpdateCategoryID, UpdateDeveloperID, AssignedTo, UpdateStatus, null, rDate));
						break;
			
			case 12: System.out.println("Enter Bug ID to be deleted");
						int deleteBugId = Integer.parseInt(br.readLine());
						controller.deleteBug(deleteBugId);
			
			
			case 13: System.out.println("Bugs with Category");
						List<Bug> bugWithcategoryNames = controller.getBugsWithCategory();
						for(Bug bug: bugWithcategoryNames) {
							System.out.println(bug.getDescription()+"BUG ID:" +bug.getBug_id());
						}
						break;
			
			case 14: System.out.println("Maximum Bugs Assigned to Developer");
						List<String> bugwithDeveloperDetails = controller.getBugsWithDeveloperDetails();
						for(String output: bugwithDeveloperDetails){
							System.out.println(output);						
						}
						break;
			
			
			case 15: System.out.println("Enter developer name");
						String devName = br.readLine();
						List<Bug> bugsAssigned = controller.getBugsAssigned(devName);
						for(Bug bug: bugsAssigned) {
							System.out.println(bug.getDescription());
							
						}
						break;
			
			case 16: System.out.println("Exiting.....");
						return;
					
			}
				
				
			
			
			
			
			}
			
			
		

	}

//	private static String categoryName() {
		// TODO Auto-generated method stub
//		return null;
	}


