package controller;

import java.sql.SQLException;
import java.util.List;

import dao.BugDAO;
import dao.CategoryDAO;
import dao.DeveloperDAO;
import model.Bug;
import model.Category;
import model.Developer;

public class BugTrackingController {
	
	private final CategoryDAO categoryDAO;
	private final DeveloperDAO developerDAO;
	private final BugDAO bugDAO;
	
	public BugTrackingController()
	{
		this.categoryDAO = new CategoryDAO();
		this.developerDAO = new DeveloperDAO();
		this.bugDAO = new BugDAO();
	}
	
	public void addCategory(Category category) throws SQLException
	{
		categoryDAO.addCategory(category);
	}
	
	public void updateCategory(Category category) throws SQLException
	{
		categoryDAO.updateCategory(category);
	}
	
	public List<Category> getAllCategories() throws SQLException
	{
		return categoryDAO.getAllCategories();
	}
	
	public void deleteCategory(int categoryId) throws SQLException
	{
		categoryDAO.deleteCategory(categoryId);
	}
	
	public void addDeveloper(Developer developer) throws SQLException
	{
		developerDAO.addDeveloper(developer);
	}
	
	public void updateDeveloper(Developer developer) throws SQLException
	{
		developerDAO.updateDeveloper(developer);
	}
	
	public List<Developer> getAllDevelopers() throws SQLException
	{
		return developerDAO.getAllDevelopers();
	}
	
	public void deleteDeveloper(int developerId) throws SQLException
	{
		developerDAO.deleteDeveloper(developerId);
	}
	public void addBug(Bug bug) throws SQLException
	{
		bugDAO.addbug(bug);
	}
	public List<Bug> getAllBugs() throws SQLException
	{
		return bugDAO.getAllBugs();
	}
	public void updateBug(Bug bug) throws SQLException
	{
		bugDAO.updateBug(bug);
	}
	public void deleteBug(int bugId) throws SQLException
	{
		bugDAO.deleteBug(bugId);
	}
	public List<Bug> getBugsWithCategory() throws SQLException
	{
		return bugDAO.getBugsWithCategory();
	}
	public List<String> getBugsWithDeveloperDetails() throws SQLException
	{
		return bugDAO.getBugsWithDeveloperDetails();
	}
	public List<Bug> getBugsAssigned(String devName) throws SQLException{
		return bugDAO.getBugAssigned(devName);
	}
}

